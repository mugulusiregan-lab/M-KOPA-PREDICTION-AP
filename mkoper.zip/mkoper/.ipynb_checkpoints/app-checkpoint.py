
import streamlit as st
import pandas as pd
import joblib

# Load the trained model and feature columns
model = joblib.load("mkopa_model.pkl")
model_columns = joblib.load("mkopa_columns.pkl")

st.title("M-KOPA Loan Repayment Prediction")

st.write(
    "Enter customer information to predict "
    "the likelihood of missing the next payment."
)

# Customer information
age = st.number_input("Customer Age", 18, 100, 30)

gender = st.selectbox(
    "Gender", ["Female", "Male", "Not stated"]
)

region = st.selectbox(
    "Region", ["Central", "Eastern", "Northern", "Western"]
)

district = st.selectbox(
    "District",
    ["Kampala", "Wakiso", "Mukono", "Mpigi",
     "Jinja", "Mbale", "Iganga", "Kamuli",
     "Gulu", "Lira", "Arua", "Kitgum",
     "Mbarara", "Hoima", "Fort Portal", "Kasese"]
)

employment = st.selectbox(
    "Employment Type",
    ["Formal employment", "Self-employed",
     "Informal work", "Other"]
)

device = st.selectbox(
    "Device Model",
    ["Samsung Galaxy A-series", "Tecno Spark",
     "Infinix Hot", "Nokia C-series", "Other Android"]
)

loan = st.number_input("Loan Amount (UGX)", 100000, 2000000, 600000)

term = st.number_input("Loan Term (Months)", 3, 24, 12)

months = st.number_input("Months on Loan", 1, 24, 6)

income = st.number_input("Monthly Income (UGX)", 100000, 5000000, 500000)

installment = st.number_input(
    "Monthly Installment (UGX)", 1000, 1000000, 60000
)

total_due = st.number_input(
    "Total Amount Due To Date (UGX)", 0, 5000000, 360000
)

paid = st.number_input(
    "Amount Paid To Date (UGX)", 0, 5000000, 200000
)

balance = st.number_input(
    "Outstanding Balance (UGX)", 0, 5000000, 400000
)

missed = st.number_input("Missed Payments", 0, 20, 1)

late = st.number_input("Days Late", 0, 365, 0)

repayment = st.slider("Repayment Rate", 0.0, 1.0, 0.8)

dti = installment / income if income > 0 else 0

channel = st.selectbox(
    "Payment Channel",
    ["Mobile Money", "Bank", "Agent", "USSD"]
)

if st.button("Predict Repayment Risk"):

    customer = pd.DataFrame([{
        "Age": age,
        "Gender": gender,
        "Region": region,
        "District": district,
        "Employment_Type": employment,
        "Device_Model": device,
        "Loan_Amount_UGX": loan,
        "Loan_Term_Months": term,
        "Months_On_Loan": months,
        "Monthly_Income_UGX": income,
        "Monthly_Installment_UGX": installment,
        "Total_Amount_Due_To_Date_UGX": total_due,
        "Amount_Paid_To_Date_UGX": paid,
        "Outstanding_Balance_UGX": balance,
        "Missed_Payments": missed,
        "Days_Late_Current": late,
        "Repayment_Rate": repayment,
        "Debt_To_Income_Ratio": dti,
        "Payment_Channel": channel
    }])

    customer = pd.get_dummies(
        customer,
        drop_first=True,
        dtype=int
    )

    customer = customer.reindex(
        columns=model_columns,
        fill_value=0
    )

    prediction = model.predict(customer)[0]
    probability = model.predict_proba(customer)[0][1]

    st.subheader("Prediction Result")

    st.metric(
        "Estimated Probability of Missing Payment",
        f"{probability:.1%}"
    )

    if prediction == 1:
        st.warning("Model predicts a missed payment.")
    else:
        st.success("Model predicts payment will be made.")

    st.caption(
        "This is an educational prediction, not a "
        "verified assessment of a real customer."
    )
